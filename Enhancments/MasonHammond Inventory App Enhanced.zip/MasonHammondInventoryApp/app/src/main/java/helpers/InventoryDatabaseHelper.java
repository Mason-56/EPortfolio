package helpers;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.masonhammondinventoryapp.InventoryActivity;
import com.example.masonhammondinventoryapp.MainActivity;
import com.example.masonhammondinventoryapp.SmsPermissions;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryDatabase.db";
    private static final String TABLE_NAME = "inventory";

    private static final String COL_2 = "ITEM_NAME";
    private static final String COL_3 = "ITEM_AMOUNT";
    private static final String COL_4 = "ITEM_IMAGE";

    public InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Inventory table
        db.execSQL(
                "CREATE TABLE " + TABLE_NAME + " (" +
                        "ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "ITEM_NAME TEXT UNIQUE, " +
                        "ITEM_AMOUNT INTEGER, " +
                        "ITEM_IMAGE TEXT)"
        );

        db.execSQL(
                "CREATE TABLE users (" +
                        "USER_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "USERNAME TEXT UNIQUE, " +
                        "PASSWORD TEXT)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS inventory");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    //Insert new item
    public boolean insertItem(String itemName, int itemAmount, String imageUri) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, itemName);
        contentValues.put(COL_3, itemAmount);
        contentValues.put(COL_4, imageUri);

        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    //Check if item exists
    public boolean itemExists(String itemName) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_NAME + " WHERE ITEM_NAME=?",
                new String[]{itemName}
        );
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    //Update item quantity
    public boolean updateItemAmount(String itemName, int newAmount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_3, newAmount);

        int result = db.update(
                TABLE_NAME,
                contentValues,
                "ITEM_NAME=?",
                new String[]{itemName}
        );

        return result > 0;
    }

    //Get all inventory items
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    // Delete item
    public boolean deleteItem(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_NAME, "ITEM_NAME=?", new String[]{itemName});
        return result > 0;
    }
}