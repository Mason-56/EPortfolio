package com.example.masonhammondinventoryapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import helpers.InventoryDatabaseHelper;

public class AddItemActivity extends AppCompatActivity {

    EditText nameInput, amountInput;
    Button addButton, cancelButton, pickImageButton;
    ImageView imageView;

    InventoryDatabaseHelper dbHelper;

    Uri imageUri = null;

    // Image picker launcher
    ActivityResultLauncher<String> imagePickerLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(),
                    uri -> {
                        if (uri != null) {
                            imageUri = uri;
                            imageView.setImageURI(uri);
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);

        nameInput = findViewById(R.id.editTextText2);
        amountInput = findViewById(R.id.editTextText4);

        addButton = findViewById(R.id.button3);
        cancelButton = findViewById(R.id.cancelButton);
        pickImageButton = findViewById(R.id.pickImage);

        imageView = findViewById(R.id.imageView);

        dbHelper = new InventoryDatabaseHelper(this);

        // Pick image button
        pickImageButton.setOnClickListener(v -> {
            imagePickerLauncher.launch("image/*");
        });

        // Add item button
        addButton.setOnClickListener(v -> addItem());

        // Cancel button
        cancelButton.setOnClickListener(v -> finish());
    }

    private void addItem() {

        String name = nameInput.getText().toString().trim();
        String amountStr = amountInput.getText().toString().trim();

        if (name.isEmpty() || amountStr.isEmpty()) {
            Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int amount;

        try {
            amount = Integer.parseInt(amountStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter a valid number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert image URI to string
        String imagePath = imageUri != null ? imageUri.toString() : "";

        boolean inserted = dbHelper.insertItem(name, amount, imagePath);

        if (inserted) {
            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Item already exists", Toast.LENGTH_SHORT).show();
        }
    }
}