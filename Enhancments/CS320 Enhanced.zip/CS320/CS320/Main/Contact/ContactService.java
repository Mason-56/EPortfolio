package Contact;

import java.util.HashMap;

public class ContactService {
	private final HashMap<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }
        if (contactExists(contact.getId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getId(),contact);
    }

    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
        	throw new IllegalArgumentException("Contact ID not found");
    	}
        contacts.remove(contactId);
    }

    public void updateFirstName(String contactId, String firstName) {
        Contact contact = findContactById(contactId);
        contact.setFirstName(firstName);
    }

    public void updateLastName(String contactId, String lastName) {
        Contact contact = findContactById(contactId);
        contact.setLastName(lastName);
    }

    public void updatePhone(String contactId, String phone) {
        Contact contact = findContactById(contactId);
        contact.setPhone(phone);
    }

    public void updateAddress(String contactId, String address) {
        Contact contact = findContactById(contactId);
        contact.setAddress(address);
    }

    public Contact getContactById(String contactId) {
        return findContactById(contactId);
    }
    
    private boolean contactExists(String contactId) {
        return contacts.containsKey(contactId);
    }

    private Contact findContactById(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
        	throw new IllegalArgumentException("Contact ID not found");
    	}
    
        return contact;
    }
}
