package Contact;

public class Contact {
	private String id;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public Contact(String id, String firstName, String lastName, String phone, String address) {
		//super();
		
		setId(id);
		setFirstName(firstName);
		setLastName(lastName);
		setPhone(phone);
		setAddress(address);
	}
	
	//The setters and getters
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		//checks the conditions
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Illegal first name");
		}
		
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		//checks the conditions
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Illegal last name");
		}
		
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		//checks the conditions
		if (phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Illegal phone number");
		}
		
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		//checks the conditions
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Illegal address");
		}
		
		this.address = address;
	}

	public String getId() {
		return id;
	}
	
	//Set as private so it cannot be updated
	private void setId(String id) {
		//checks the conditions
		if (id == null || id.trim().length() < 1 || id.length() > 10) {
		    throw new IllegalArgumentException("Illegal id");
		}
		
		this.id = id;
	}
}
