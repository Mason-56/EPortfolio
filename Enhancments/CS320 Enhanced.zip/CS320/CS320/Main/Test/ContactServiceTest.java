package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Contact.Contact;
import Contact.ContactService;

class ContactServiceTest {
	private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

	@Test
	public void testAddContactSuccess() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        assertEquals("John", service.getContactById("001").getFirstName());
    }

    @Test
    public void testDeleteContactSuccess() {
        Contact contact = new Contact("002", "Alice", "Brown", "1234567890", "789 Pine Rd");
        service.addContact(contact);
        service.deleteContact("002");
        assertThrows(IllegalArgumentException.class, () -> service.getContactById("002"));
    }

    @Test
    public void testUpdateFirstNameSuccess() {
        Contact contact = new Contact("003", "Tom", "Ford", "1234567890", "999 Elm St");
        service.addContact(contact);
        service.updateFirstName("003", "Jerry");
        assertEquals("Jerry", service.getContactById("003").getFirstName());
    }

    @Test
    public void testUpdateLastNameSuccess() {
        Contact contact = new Contact("004", "Tom", "Ford", "1234567890", "999 Elm St");
        service.addContact(contact);
        service.updateLastName("004", "Smith");
        assertEquals("Smith", service.getContactById("004").getLastName());
    }

    @Test
    public void testUpdatePhoneSuccess() {
        Contact contact = new Contact("005", "Tom", "Ford", "1234567890", "999 Elm St");
        service.addContact(contact);
        service.updatePhone("005", "0987654321");
        assertEquals("0987654321", service.getContactById("005").getPhone());
    }

    @Test
    public void testUpdateAddressSuccess() {
        Contact contact = new Contact("006", "Tom", "Ford", "1234567890", "999 Elm St");
        service.addContact(contact);
        service.updateAddress("006", "New Address");
        assertEquals("New Address", service.getContactById("006").getAddress());
    }
}
