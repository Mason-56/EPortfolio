package Test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import Contact.Contact;


class ContactTest {
	@Test
	void testContactClass() {
	    Contact contact = new Contact("14235", "FirstName", "LastName", "PhoneNumbr", "Address");
	    assertTrue(contact.getFirstName().equals("FirstName"));
	    assertTrue(contact.getLastName().equals("LastName"));
	    assertTrue(contact.getId().equals("14235"));
	    assertTrue(contact.getPhone().equals("PhoneNumbr"));
	    assertTrue(contact.getAddress().equals("Address"));
	}

	@Test
	void testFirstNameTooLong() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("14235", "FirstNameIsWayTooLong", "LastName", "PhoneNumbr", "Address");
	    });
	}
	
	@Test
	void testFirstNameIsNull() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("14235", null, "LastName", "PhoneNumbr", "Address");
	    });
	}
	
	@Test
	void testLastNameTooLong() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("14235", "FirstName", "LastNameIsWayTooLong", "PhoneNumbr", "Address");
	    });
	}
	
	@Test
	void testLastNameIsNull() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("14235", "FirstName", null, "PhoneNumbr", "Address");
	    });
	}
	
	@Test
	void testIdTooLong() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("14235678912", "FirstName", "LastName", "PhoneNumbr", "Address");
	    });
	}
	
	@Test
	void testIdIsNull() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact(null, "FirstName", "LastName", "PhoneNumbr", "Address");
	    });
	}
	
	@Test
	void testPhoneNumberTooLong() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("14235", "FirstName", "LastName", "PhoneNumber", "Address");
	    });
	}
	
	@Test
	void testPhoneNumberIsNull() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("14235", "FirstName", "LastName", null, "Address");
	    });
	}
	
	@Test
	void testAddressTooLong() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("14235", "FirstName", "LastName", "PhoneNumbr", "ThisAddressIsGoingTooBeWayToLongForTheLimit");
	    });
	}
	
	@Test
	void testAddressIsNull() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("14235", "FirstName", "LastName", "PhoneNumbr", null);
	    });
	}
}
