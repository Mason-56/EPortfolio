from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password, host, port, database, collection): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'SNHU545' 
        HOST = 'localhost' 
        PORT = 27017
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            insert = self.database.animals.insert_one(data)
            if insert != 0:
                return True
            else:
                return False
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 
    
    # Create method to implement the R in CRUD.
    def read(self, data):
        if data is not None: 
            results = list(self.database.animals.find(data))
            return results
        else: 
            return []
    
    # Create method to implement the U in CRUD.
    def update(self, query, update_data, many=False):
        if query is not None and update_data is not None:
            if many:
                result = self.database.animals.update_many(query, update_data)
            else:
                result = self.database.animals.update_one(query, update_data)

            return result.modified_count
        else:
            raise Exception("Query or update data is empty")
    
    
    # Create method to implement the D in CRUD.
    def delete(self, data):
        if data is not None:
            result = self.database.animals.delete_many(data)
            
            return result.deleted_count
        else:
            return 0