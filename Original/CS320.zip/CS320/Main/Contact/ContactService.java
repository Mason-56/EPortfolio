package Contact;

import java.util.ArrayList;

public class ContactService {
	private final ArrayList<Contact> contacts = new ArrayList<>();

    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }
        if (contactExists(contact.getId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.add(contact);
    }

    public void deleteContact(String contactId) {
        Contact contact = findContactById(contactId);
        contacts.remove(contact);
    }

    public void updateFirstName(String contactId, String firstName) {
        Contact contact = findContactById(contactId);
        contact.setFirstName(firstName);
    }

    public void updateLastName(String contactId, String lastName) {
        Contact contact = findContactById(contactId);
        contact.setLastName(lastName);
    }

    public void updatePhone(String contactId, String phone) {
        Contact contact = findContactById(contactId);
        contact.setPhone(phone);
    }

    public void updateAddress(String contactId, String address) {
        Contact contact = findContactById(contactId);
        contact.setAddress(address);
    }

    public Contact getContactById(String contactId) {
        return findContactById(contactId);
    }
    
    private boolean contactExists(String contactId) {
        for (int i = 0; i < contacts.size(); i++) {
        	Contact c = contacts.get(i);
        	if (c.getId().equals(contactId)) {
                return true;
            }
        }
        return false;
    }

    private Contact findContactById(String contactId) {
        for (int i = 0; i < contacts.size(); i++) {
        	Contact c = contacts.get(i);
        	if (c.getId().equals(contactId)) {
                return c;
            }
        }
        throw new IllegalArgumentException("Contact ID not found");
    }
}
