package helpers;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

public class SmsHelper {
    public static void sendZeroInventorySms(Context context, String phoneNumber, String itemName) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        if (phoneNumber == null || phoneNumber.isEmpty()) {
            return;
        }

        String message = itemName + " has reached zero inventory. Time to restock.";

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }
}