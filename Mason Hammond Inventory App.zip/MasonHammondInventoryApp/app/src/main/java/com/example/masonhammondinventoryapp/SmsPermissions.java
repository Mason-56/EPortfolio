package com.example.masonhammondinventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissions extends AppCompatActivity {

    private Button closeButton;
    private Switch switchPermission;
    private EditText etPhoneNumber;

    private static final String PREFS_NAME = "inventory_prefs";
    private static final String KEY_PERMISSION_SWITCH = "permission_switch";
    private static final String KEY_PHONE_NUMBER = "sms_phone_number";

    private static final int SMS_PERMISSION_CODE = 2001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_permissions);

        closeButton = findViewById(R.id.closeButton);
        switchPermission = findViewById(R.id.switchPermission);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Load saved state
        boolean isEnabled = prefs.getBoolean(KEY_PERMISSION_SWITCH, false);
        switchPermission.setChecked(isEnabled);

        String savedNumber = prefs.getString(KEY_PHONE_NUMBER, "");
        etPhoneNumber.setText(savedNumber);

        // Toggle SMS permission
        switchPermission.setOnCheckedChangeListener((buttonView, isChecked) -> {
            String number = etPhoneNumber.getText().toString().trim();
            if (isChecked) {
                if (number.isEmpty()) {
                    Toast.makeText(this, "Please enter a phone number first.", Toast.LENGTH_SHORT).show();
                    switchPermission.setChecked(false);
                    return;
                }
                requestSmsPermissionIfNeeded(number);
            } else {
                savePermissionState(false, "");
            }
        });

        closeButton.setOnClickListener(v -> {
            Intent intent = new Intent(SmsPermissions.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void requestSmsPermissionIfNeeded(String phoneNumber) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        } else {
            savePermissionState(true, phoneNumber);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            boolean granted = grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED;

            String number = etPhoneNumber.getText().toString().trim();
            if (granted) {
                savePermissionState(true, number);
                switchPermission.setChecked(true);
            } else {
                savePermissionState(false, "");
                switchPermission.setChecked(false);
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void savePermissionState(boolean enabled, String phoneNumber) {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
        editor.putBoolean(KEY_PERMISSION_SWITCH, enabled);
        editor.putString(KEY_PHONE_NUMBER, phoneNumber);
        editor.apply();
    }
}