package com.example.masonhammondinventoryapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import helpers.InventoryDatabaseHelper;
import helpers.SmsHelper;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private Cursor cursor;
    private Context context;
    private InventoryDatabaseHelper dbHelper;

    public InventoryAdapter(Context context, Cursor cursor) {
        this.context = context;
        this.cursor = cursor;
        this.dbHelper = new InventoryDatabaseHelper(context);
    }

    public void swapCursor(Cursor newCursor) {
        if (cursor != null) cursor.close();
        cursor = newCursor;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.row_delete, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (!cursor.moveToPosition(position)) return;

        String name = cursor.getString(cursor.getColumnIndexOrThrow("ITEM_NAME"));
        int amount = cursor.getInt(cursor.getColumnIndexOrThrow("ITEM_AMOUNT"));

        holder.name.setText(name);
        holder.amount.setText(String.valueOf(amount));

        holder.plusButton.setOnClickListener(v -> {
            int newAmount = amount + 1;
            dbHelper.updateItemAmount(name, newAmount);
            holder.amount.setText(String.valueOf(newAmount));
            swapCursor(dbHelper.getAllItems());
        });

        holder.minusButton.setOnClickListener(v -> {
            int currentAmount = cursor.getInt(
                    cursor.getColumnIndexOrThrow("ITEM_AMOUNT"));

            if (currentAmount > 0) {
                int newAmount = currentAmount - 1;

                dbHelper.updateItemAmount(name, newAmount);
                holder.amount.setText(String.valueOf(newAmount));
                swapCursor(dbHelper.getAllItems());

                if (newAmount == 0) {SharedPreferences prefs = context.getSharedPreferences("inventory_prefs", Context.MODE_PRIVATE);
                    boolean smsEnabled = prefs.getBoolean("permission_switch", false);
                    String phoneNumber = prefs.getString("sms_phone_number", "");

                    if (smsEnabled && phoneNumber != null && !phoneNumber.isEmpty()) {
                        SmsHelper.sendZeroInventorySms(context, phoneNumber, name);
                    }
                }
            }
        });

        holder.deleteButton.setOnClickListener(v -> {
            dbHelper.deleteItem(name);
            swapCursor(dbHelper.getAllItems());
        });
    }

    @Override
    public int getItemCount() {
        return cursor == null ? 0 : cursor.getCount();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, amount;
        Button deleteButton, plusButton, minusButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.item_name);
            amount = itemView.findViewById(R.id.item_amount);
            deleteButton = itemView.findViewById(R.id.delete_button);
            plusButton = itemView.findViewById(R.id.plus_button);
            minusButton = itemView.findViewById(R.id.minus_button);
        }
    }
}