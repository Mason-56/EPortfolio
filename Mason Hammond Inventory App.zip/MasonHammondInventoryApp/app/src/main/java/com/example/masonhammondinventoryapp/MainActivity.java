package com.example.masonhammondinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import helpers.DatabaseHelper;

public class MainActivity extends AppCompatActivity {
//Username: testingstuff
//Password: TestingPass12
    EditText usernameEditText;
    TextInputEditText passwordEditText;
    Button loginButton, createButton;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.editTextText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.button);
        createButton = findViewById(R.id.button2);

        db = new DatabaseHelper(this);

        //Login Button
        loginButton.setOnClickListener(v -> {
            String user = usernameEditText.getText().toString().trim();
            String pass = passwordEditText.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.checkUser(user, pass)) {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this, SmsPermissions.class);
                startActivity(intent);
                finish();

            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        //Create Account Button
        createButton.setOnClickListener(v -> {
            String user = usernameEditText.getText().toString().trim();
            String pass = passwordEditText.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.userExists(user)) {
                Toast.makeText(this, "User already exists", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted = db.insertUser(user, pass);

            if (inserted) {
                Toast.makeText(this, "Account created!", Toast.LENGTH_SHORT).show();

                if (db.checkUser(user, pass)) {
                    Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(MainActivity.this, SmsPermissions.class);
                    startActivity(intent);
                    finish();
                }
            } else {
                Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
            }
        });
    }
}