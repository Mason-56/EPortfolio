package com.example.masonhammondinventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import helpers.InventoryDatabaseHelper;

public class AddItemActivity extends AppCompatActivity {

    EditText nameInput, amountInput;
    Button addButton;
    InventoryDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);

        nameInput = findViewById(R.id.editTextText2);
        amountInput = findViewById(R.id.editTextText4);
        addButton = findViewById(R.id.button3);

        dbHelper = new InventoryDatabaseHelper(this);

        addButton.setOnClickListener(v -> addItem());
    }

    private void addItem() {
        String name = nameInput.getText().toString().trim();
        String amountStr = amountInput.getText().toString().trim();

        if (name.isEmpty() || amountStr.isEmpty()) {
            Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int amount = Integer.parseInt(amountStr);

        boolean inserted = dbHelper.insertItem(name, amount);

        if (inserted) {
            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Item already exists", Toast.LENGTH_SHORT).show();
        }
    }
}