package com.example.masonhammondinventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import helpers.InventoryDatabaseHelper;

public class InventoryActivity extends AppCompatActivity {

    FloatingActionButton addItemButton;
    RecyclerView recyclerView;
    InventoryDatabaseHelper dbHelper;
    InventoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_database);

        recyclerView = findViewById(R.id.data);
        addItemButton = findViewById(R.id.floatingActionButton);

        dbHelper = new InventoryDatabaseHelper(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Cursor cursor = dbHelper.getAllItems();
        adapter = new InventoryAdapter(this, cursor);
        recyclerView.setAdapter(adapter);

        addItemButton.setOnClickListener(v -> {
            startActivity(new Intent(this, AddItemActivity.class));
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter.swapCursor(dbHelper.getAllItems());
    }
}